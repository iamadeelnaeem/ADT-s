#include "XorLL.h"
template <typename T>
XorLL<T>::XorLL(const XorLL<T> &obj) : XorLL()
{
    Node<T> *cur = obj.head;
    Node<T> *prev = NULL;
    Node<T> *temp = NULL;
    while (prev != obj.tail)
    {
        insertAtTail(cur->data);
        temp = XOR(prev, cur->ptr);
        prev = cur;
        cur = temp;
    }
}
template <typename T>
const XorLL<T> &XorLL<T>::operator=(const XorLL<T> &obj)
{
    if (this == &obj)
        return *this;
    if (head)
        this->~XorLL();
    Node<T> *cur = obj.head;
    Node<T> *prev = NULL;
    Node<T> *temp = NULL;
    while (prev != obj.tail)
    {
        insertAtTail(cur->data);
        temp = XOR(prev, cur->ptr);
        prev = cur;
        cur = temp;
    }
    return *this;
}
template <typename T>
XorLL<T>::~XorLL()
{
    if (!isEmpty())
    {
        Node<T> *cur = head->ptr;
        Node<T> *prev = head;
        Node<T> *temp = NULL;
        while (prev != tail)
        {
            temp = XOR(prev, cur->ptr);
            if (prev)
            {
                delete prev;
            }
            prev = cur;
            cur = temp;
        }
        if (head)
        {
            delete head;
            head = NULL;
        }
        if (tail)
        {
            delete tail;
            tail = NULL;
        }
        head = tail = NULL;
    }
}
template <typename T>
Node<T> *XorLL<T>::search(T val)
{
    if (!isEmpty())
    {
        if (val == head->data)
            return head;
        if (val == tail->data)
            return tail;
        Node<T> *cur = head;
        Node<T> *prev = NULL;
        Node<T> *temp = NULL;
        while (prev != tail)
        {
            if (cur->data == val)
                return cur;
            temp = XOR(prev, cur->ptr);
            prev = cur;
            cur = temp;
        }
    }
    return NULL;
}
template <typename T>
Node<T> *XorLL<T>::XOR(Node<T> *x, Node<T> *y)
{
    return (Node<T> *)((uintptr_t)(x) ^ (uintptr_t)(y));
}
template <typename T>
bool XorLL<T>::isEmpty()
{
    if (head == NULL)
        return true;
    return false;
}
template <typename T>
void XorLL<T>::insertAtHead(T val)
{
    if (!isEmpty())
    {
        if (head->ptr == NULL)
        {
            Node<T> *tail = head;
            head = new Node<T>(val);
            tail->ptr = head;
            head->ptr = tail;
        }
        else
        {
            Node<T> *temp = head;
            head = new Node<T>(val);
            temp->ptr = XOR(head, temp->ptr);
            head->ptr = temp;
        }
    }
    else
    {
        head = new Node<T>(val);
        tail = head;
        tail->ptr = NULL;
        head->ptr = NULL;
    }
}
template <typename T>
void XorLL<T>::insertAfter(T key, T val)
{
    if (isEmpty())
        insertAtHead(val);
    else if (tail->data == key)
        insertAtTail(val);
    else
    {
        Node<T> *cur = head;
        Node<T> *prev = NULL;
        Node<T> *temp = NULL;
        while (prev != tail)
        {
            if (cur->data == key)
            {
                Node<T> *newNode = new Node<T>(val);
                temp = XOR(prev, cur->ptr);
                newNode->ptr = XOR(cur, temp);
                cur->ptr = XOR(newNode, prev);
                temp->ptr = XOR(XOR(temp->ptr, cur), newNode);
                return;
            }
            temp = XOR(prev, cur->ptr);
            prev = cur;
            cur = temp;
        }
        insertAtHead(val);
    }
}
template <typename T>
void XorLL<T>::insertBefore(T key, T val)
{
    if (isEmpty())
        insertAtHead(val);
    else if (key == head->data)
        insertAtHead(val);
    else
    {
        Node<T> *cur = head;
        Node<T> *prev = NULL;
        Node<T> *temp = NULL;
        while (prev != tail)
        {
            if (cur->data == key)
            {
                Node<T> *newNode = new Node<T>(val);
                temp = XOR(cur, prev->ptr);
                newNode->ptr = XOR(cur, prev);
                prev->ptr = XOR(newNode, temp);
                cur->ptr = XOR(XOR(prev, cur->ptr), newNode);
                return;
            }
            temp = XOR(prev, cur->ptr);
            prev = cur;
            cur = temp;
        }
        insertAtHead(val);
    }
}
template <typename T>
void XorLL<T>::insertAtTail(T val)
{
    if (isEmpty())
    {
        head = new Node<T>(val);
        tail = head;
        head->ptr = tail->ptr = NULL;
    }
    else
    {
        Node<T> *cur = tail;
        Node<T> *prev = tail->ptr;
        Node<T> *newNode = new Node<T>(val);
        newNode->ptr = XOR(tail, NULL);
        tail = newNode;
        cur->ptr = XOR(prev, newNode);
    }
}
template <typename T>
void XorLL<T>::sortedInsert(T val)
{
    if (isEmpty())
        insertAtHead(val);
    else if (head->data > val)
        insertAtHead(val);
    else
    {
        Node<T> *cur = head;
        Node<T> *prev = NULL;
        Node<T> *temp = NULL;
        while (prev != tail)
        {
            if (cur->data >= val)
            {

                Node<T> *newNode = new Node<T>(val);
                temp = XOR(cur, prev->ptr);
                newNode->ptr = XOR(cur, prev);
                prev->ptr = XOR(newNode, temp);
                cur->ptr = XOR(XOR(cur->ptr, prev),newNode);
                return;
            }
            temp = XOR(prev, cur->ptr);
            prev = cur;
            cur = temp;
        }
        insertAtTail(val);
    }
}
template <typename T>
bool XorLL<T>::deleteAtTail()
{
    if (isEmpty())
        return false;
    if (head == tail)
    {
        this->~XorLL();
        return true;
    }
    else
    {
        Node<T> *cur = tail;
        Node<T> *prev = tail->ptr;
        Node<T> *temp = XOR(prev->ptr, cur);
        tail = prev;
        delete cur;
        cur = NULL;
        tail->ptr = XOR(temp, cur);
        return true;
    }
}
template <typename T>
bool XorLL<T>::deleteAtHead()
{
    if (isEmpty())
        return false;
    if (head == tail)
    {
        this->~XorLL();
        return true;
    }
    else
    {
        Node<T> *prev = head;
        Node<T> *cur = head->ptr;
        Node<T> *temp = XOR(cur->ptr, prev);
        head = cur;
        delete prev;
        prev = NULL;
        head->ptr = XOR(temp, prev);
        return true;
    }
}
template <typename T>
bool XorLL<T>::deleteAfter(T key)
{
    if (isEmpty())
        return false;
    else if (tail->data == key)
        return false;
    else
    {
        Node<T> *prev = head;
        Node<T> *cur = head->ptr;
        Node<T> *temp = NULL;
        while (prev != tail)
        {
            if (prev->data == key)
            {
                if (cur == tail)
                    deleteAtTail();
                else
                {
                    temp = XOR(prev, cur->ptr);
                    prev->ptr = XOR(XOR(cur, prev->ptr), temp);
                    temp->ptr = XOR(XOR(cur, temp->ptr), prev);
                    delete cur;
                    cur = NULL;
                }
                return true;
            }
            temp = XOR(prev, cur->ptr);
            prev = cur;
            cur = temp;
        }
        return false;
    }
}
template <typename T>
bool XorLL<T>::deleteBefore(T key)
{
    if (isEmpty())
        return false;
    else if (key == head->data)
        return false;
    else if (val == head->ptr->data)
    {
        removeAtHead();
        return true;
    }
    else
    {
        Node<T> *cur = head;
        Node<T> *prev = NULL;
        Node<T> *temp = NULL;
        while (prev != tail)
        {
            if (cur->data == key)
            {
                temp = XOR(cur, prev->ptr);
                temp->ptr = XOR(XOR(temp->ptr, prev), cur);
                cur->ptr = XOR(XOR(cur->ptr, prev), temp);
                delete prev;
                prev = NULL;
                return true;
            }
            temp = XOR(prev, cur->ptr);
            prev = cur;
            cur = temp;
        }
    }
    return false;
}
template <typename T>
bool XorLL<T>::deleteAt(T key)
{
    if (isEmpty())
        return false;
    if (head->data == key)
    {
        deleteAtHead();
        return true;
    }
    if (tail->data == key)
    {
        deleteAtTail();
        return true;
    }
    Node<T> *cur = head;
    Node<T> *prev = NULL;
    Node<T> *temp = NULL;
    while (prev != tail)
    {
        if (cur->data == key)
        {
            temp = XOR(cur->ptr, prev);
            temp->ptr = XOR(XOR(temp->ptr, cur), prev);
            prev->ptr = XOR(XOR(cur, prev->ptr), temp);
            delete cur;
            cur = NULL;
            return true;
        }
        temp = XOR(prev, cur->ptr);
        prev = cur;
        cur = temp;
    }
    return false;
}
template <typename T>
void XorLL<T>::print() const
{
    Node<T> *cur = head,
            *prev = NULL, *temp = NULL;
    while (prev != tail)
    {
        cout << cur->data << " -> ";
        temp = (Node<T> *)((uintptr_t)(prev) ^ (uintptr_t)(cur->ptr));
        ;
        prev = cur;
        cur = temp;
    }
    cout << endl;
}
template <typename T>
void XorLL<T>::printReverse() const
{
    Node<T> *cur = tail,
            *prev = tail->ptr, *temp = NULL;
    while (cur != head)
    {
        cout << cur->data << " -> ";
        temp = (Node<T> *)((uintptr_t)(prev->ptr) ^ (uintptr_t)(cur));
        ;
        cur = prev;
        prev = temp;
    }
    cout << cur->data << endl;
}
template <typename T>
int XorLL<T>::getLength() const
{
    int count = 0;
    if (head == NULL)
        return 0;
    else
    {
        Node<T> *cur = head;
        Node<T> *prev = NULL;
        Node<T> *temp = NULL;
        while (prev != tail)
        {
            count++;
            temp = (Node<T> *)((uintptr_t)(prev) ^ (uintptr_t)(cur->ptr));
            prev = cur;
            cur = temp;
        }
        return count;
    }
}
template <typename T>
Node<T> *XorLL<T>::getNode(int n)
{
    if (n < 0 || n > getLength())
        return NULL;
    else
    {
        Node<T> *cur = head;
        Node<T> *prev = NULL;
        Node<T> *temp = NULL;
        n--;
        while (n)
        {
            temp = (Node<T> *)((uintptr_t)(prev) ^ (uintptr_t)(cur->ptr));
            prev = cur;
            cur = temp;
            n--;
        }
        return cur;
    }
}