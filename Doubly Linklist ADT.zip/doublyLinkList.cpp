// Abdul Aziz
// BCSF19A026
// CS Afternoon Add/Drop
#include <iostream>
using namespace std;
template <class U>
class doublyLinkList;
template <class T>
class Node
{
    T data;
    Node<T> *next;
    Node<T> *previous;

public:
    friend class doublyLinkList<T>;
    Node(T d);
};
template <class T>
Node<T>::Node(T d)
{
    data = d;
    previous = NULL;
    next = NULL;
}
template <class T>
class doublyLinkList
{
    Node<T> *head;
    Node<T> *tail;

public:
    doublyLinkList();
    ~doublyLinkList();
    bool isEmpty();
    Node<T> *search(T);
    void printList();
    void insertAtHead(T);
    void insertAtTail(T);
    void insertBefore(T, T);
    void insertAfter(T, T);
    bool deleteAtHead();
    bool deleteAtTail();
    bool deleteBefore(T, T);
    bool deleteAfter(T, T);
    bool deleteAt(T);
};
template <class T>
doublyLinkList<T>::doublyLinkList()
{
    head = NULL;
    tail = NULL;
}
template <class T>
doublyLinkList<T>::~doublyLinkList()
{
    Node<T> *temp = head;
    while (temp)
    {
        head = head->next;
        delete temp;
        temp = head;
    }
}
template <class T>
bool doublyLinkList<T>::isEmpty()
{
    return head == NULL;
}

template <class T>
void doublyLinkList<T>::printList()
{
    Node<T> *temp = head;
    while (temp)
    {
        head = head->next;
        cout << temp->data << "-->";
        temp = head;
    }
    cout << "nullptr\n";
}
template <class T>
void doublyLinkList<T>::insertAtHead(T val)
{
    Node<T> *temp = new Node<T>(val);
    if (isEmpty())
    {
        head = tail = temp;
    }
    else
    {
        head->previous = temp;
        temp->next = head;
        head = temp;
    }
}
template <class T>
void doublyLinkList<T>::insertAtTail(T val)
{
    Node<T> *temp = new Node<T>(val);
    if (isEmpty())
    {
        head = tail = temp;
    }
    else
    {
        tail->next = temp;
        temp->previous = tail;
        tail = temp;
    }
}
template <class T>
void doublyLinkList<T>::insertBefore(T key, T val)
{
    Node<T> *newNode = new Node<T>(val);
    Node<T> *currentNode = searching(key);
    if (currentNode == head)
    {
        insertAtHead(val);
    }
    else if (currentNode)
    {
        newNode->previous = currentNode->previous;
        newNode->previous->next = newNode;
        newNode->next = currentNode;
        currentNode->previous = newNode;
    }
}
template <class T>
void doublyLinkList<T>::insertAfter(T key, T val)
{
    Node<T> *newNode = new Node<T>(val);
    Node<T> *currentNode = searching(key);
    if (currentNode == tail)
    {
        insertAtTail(val);
    }
    else if (currentNode)
    {
        newNode->next = currentNode->next;
        newNode->next->previous = newNode;
        newNode->previous = currentNode;
        currentNode->next = newNode;
    }
}
template <class T>
Node<T> *doublyLinkList<T>::search(T key)
{
    Node<T> *temp = head;
    while (temp)
    {
        if (temp->data == key)
        {
            return temp;
        }
        else
        {
            temp = temp->next;
        }
    }
    return nullptr;
}
template <class T>
bool doublyLinkList<T>::deleteBefore(T key, T val)
{
    Node<T> *temp = head;
    if (head->data == key)
    {
        return false;
    }
    else if (head->next->data == key)
    {
        deleteAtHead();
        return true;
    }
    else if (temp)
    {
        while (temp)
        {
            if (temp->data == key)
            {
                temp->previous->previous->next = temp;
                Node<T> *d = temp->previous;
                temp->previous = temp->previous->previous;
                delete d;
                d = NULL;
                return true;
            }
            else
            {
                temp = temp->next;
            }
        }
    }
    return false;
}
template <class T>
bool doublyLinkList<T>::deleteAfter(T key, T val)
{
    Node<T> *temp = head;
    if (tail->data == key)
    {
        return false;
    }
    else if (temp)
    {
        while (temp)
        {
            if (temp->data == key)
            {
                Node<T> *d = temp->next;
                temp->next = d->next;
                d->next->previous = temp;
                delete d;
                d = NULL;
                return true;
            }
            else
            {
                temp = temp->next;
            }
        }
    }
    return false;
}

template <class T>
bool doublyLinkList<T>::deleteAt(T key)
{

    if (head->data == key)
    {
        deleteAtHead();
        return true;
    }
    else if (tail->data == key)
    {
        deleteAtTail();
        return true;
    }
    else
    {
        Node<T> *temp = head;
        while (temp)
        {
            if (temp->data == key)
            {
                temp->previous->next = temp->next;
                temp->next->previous = temp->previous;
                delete temp;
                temp = NULL;
                return true;
            }
            else
                temp = temp->next;
        }
    }
    return false;
}

template <class T>
bool doublyLinkList<T>::deleteAtHead()
{
    if (!isEmpty())
    {
        Node<T> *temp = head;
        head = head->next;
        delete temp;
        head->previous = NULL;
        return true;
    }
    return false;
}
template <class T>
bool doublyLinkList<T>::deleteAtTail()
{
    if (!isEmpty())
    {
        Node<T> *temp = tail;
        if (tail->previous)
        {
            tail = tail->previous;
            delete temp;
            tail->next = NULL;
            return true;
        }
        
    }
    return false;
}

int main()
{
    doublyLinkList<int> d;
    d.insertAtHead(4);
    d.insertAtTail(9);
    d.insertAfter(9, 10);
    d.insertAfter(9, 8);
    d.insertBefore(9, 11);
    d.insertBefore(4, 1);
    d.printList();
    // d.deleteAtHead();
    d.deleteAtTail();
    d.printList();
}