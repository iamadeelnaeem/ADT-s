#ifndef QUEUE_H
#define QUEUE_H
#include <iostream>
#include <iomanip>
#include <cmath>
#include <string>
#include <cstring>
#include <cctype>
using namespace std;
template <typename T>
class Queue
{
private:
    /* data */
    T *data;
    int capacity;
    int size;
    int front;
    int rear;
    void reSize(const int &);

public:
    Queue(/* args */);
    Queue(const Queue<T> &);
    const Queue<T> &operator=(const Queue<T> &);
    ~Queue();
    void enQueue(const T &);
    const T deQueue();
    const int getSize();
    const int getCapacity();
    bool isFull() const;
    bool isEmpty() const;
    void display()
    {
        cout << "isEmpty(): " << isEmpty() << endl;
        cout << "isFull(): " << isFull() << endl;
        cout << "Size: " << size << endl;
        cout << "Capacity: " << capacity << endl;
        cout << "Front: " << front << endl;
        cout << "Rear: " << rear << endl;
        cout << "Data: ";
        for (int i = 0; i < size; i++)
            cout << data[(front + i) % capacity] << " ";
        cout << endl;
    }
};
#endif
