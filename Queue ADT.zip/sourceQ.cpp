#include "Queue.h"
#include "Queue.cpp"
int main()
{
    Queue<int> q{};
    q.display();
    for (int i = 0; i < 10; i++)
    {
        for (int j = -i; j <= i; j++)
        {
            q.enQueue(j);
            q.enQueue(j * 10);
            q.deQueue();
        }
        q.display();
        while (!q.isEmpty())
            q.deQueue();
        cout << endl
             << endl;
    }
    return 0;
}