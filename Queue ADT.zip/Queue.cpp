#include "Queue.h"
template <typename T>
Queue<T>::Queue(/* args */)
{
    front = 0;
    rear = 0;
    size = 0;
    capacity = 0;
    data = NULL;
}
template <typename T>
Queue<T>::Queue(const Queue<T> &obj)
{
    size = obj.size;
    front = obj.front;
    rear = obj.rear;
    capacity = obj.capacity;
    data = new T[capacity]{};
    for (int i = 0; i < size; i++)
        data[(front + i) % capacity] = obj.data[(front + i) % capacity];
}
template <typename T>
const Queue<T> &Queue<T>::operator=(const Queue<T> &obj)
{
    if (this == &obj)
        return *this;
    if (data)
        this->~Queue();
    size = obj.size;
    front = obj.front;
    rear = obj.rear;
    capacity = obj.capacity;
    data = new T[capacity]{};
    for (int i = 0; i < size; i++)
        data[(front + i) % capacity] = obj.data[(front + i) % capacity];
    return *this;
}
template <typename T>
Queue<T>::~Queue()
{
    if (data)
    {
        delete[] data;
        data = NULL;
        rear = 0;
        front = 0;
        capacity = 0;
        size = 0;
    }
}
template <typename T>
void Queue<T>::reSize(const int &s)
{
    T *data1 = new T[s]{};
    for (int i = 0; i < size; i++)
        data1[i] = data[(front + i) % capacity];
    front = 0;
    rear = size;
    delete[] data;
    capacity = s;
    data = data1;
    data1 = NULL;
}
template <typename T>
void Queue<T>::enQueue(const T &val)
{
    if (isFull())
        if (capacity)
            reSize(capacity * 2);
        else
            data = new T[++capacity]{};
    rear = rear % capacity;
    data[rear++] = val;
    size++;
}
template <typename T>
const T Queue<T>::deQueue()
{
    if (isEmpty())
    {
        cout << "Queue is empty\n";
        exit(0);
    }
    else
    {
        if (size == capacity / 4)
            reSize(capacity/2);
        front = front % capacity;
        size--;
        return data[front++];
    }
}
template <typename T>
const int Queue<T>::getSize()
{
    return size;
}
template <typename T>
const int Queue<T>::getCapacity()
{
    return capacity;
}
template <typename T>
bool Queue<T>::isFull()const
{
    if (size == capacity)
        return true;
    else
        return false;
}
template <typename T>
bool Queue<T>::isEmpty()const
{
    if (size == 0)
        return true;
    else
        return false;
}