//****************************************************************
//              Abdul Aziz
//              BCSF19A026
//              CS Afternoon Add/Drop
//****************************************************************
#ifndef BST_H
#define BST_H
#include <iostream>
#include <queue>
using namespace std;

template <typename T>
class AVLNode;
template <typename T>
class BSTNode
{
    friend class BST<T>;
    T data;
    BSTNode<T> *right, *left;

public:
    BSTNode() : data({}), right(NULL), left(NULL) {}
    BSTNode(T val) : data(val), right(NULL), left(NULL) {}
    void printNode()
    {
        cout << "Node Data: " << data << endl;
    }
};
template <typename T>
class BST
{
    BSTNode<T> *root;
    // private functions
    void makeBST(BSTNode<T> *, BSTNode<T> *);
    void deleteBST(BSTNode<T> *);
    void LVR(BSTNode<T> *) const;
    void VLR(BSTNode<T> *) const;
    void LRV(BSTNode<T> *) const;
    int getHeight(BSTNode<T> *);
    int getNoOfNodes(BSTNode<T> *);
public:
    BST();
    BST(const BST<T> &);
    const BST<T> &operator=(const BST<T> &);
    ~BST();
    BSTNode<T> * search(T);
    void insert(T);
    bool deleteNode(T);
    bool isBST(BSTNode<T> *);
    bool isEqual(BSTNode<T> *, BSTNode<T> *);
    int getHeight();
    int getNodeCount( BST<T> *);
    T getMinMax(int);
    void setRoot(T);
    BSTNode<T> * getLeftChild(BSTNode<T> *);
    BSTNode<T> * getRightChild(BSTNode<T> *);
    void print()const;
    void printTree();

};
#endif