//  Abdul Aziz
//  BCSF19A026
//  CS Afternoon Add/Drop

#include "BST.cpp"
#include <windows.h>

void validate(int &);
int main()
{
    BST<int> tree;
    BST<int> tree1;
    cout << "****************************************************************\n";
    cout << "                       **~ WELCOME ~**\n";
    cout << "****************************************************************\n";
    Sleep(500);
    while (true)
    {
        system("cls");
        tree.printTree();
        cout << "\nPlease select from the list below" << endl;
        cout << "1 -> Set Root of BST\n2 -> Insert a new node\n3 -> Remove a node\n4 -> Search a node\n5 -> Print in level order format" << endl;
        cout << "6 -> Get Height (Level of the Tree)\n7 -> Checking for as BST\n8 -> Checking for as Equal" << endl;
        cout << "9 -> Get Min/Max Node value\n10 -> Get Copy of the tree\n11 -> Get No of Nodes\n12 -> Print BST (LVR, LRV, VLR)\n0 -> Exit\nYour Selection: ";
        int choice = 0;
        while (cin >> choice && (choice < 0 || choice > 12))
            cout << "Invalid Selection: " << choice << endl
                 << "Please select a choice between 1-11: ";
        if (choice == 0)
            exit(0);
        else if (choice == 1)
        {
            cout << "Enter root: ";
            int root;
            cin >> root;
            validate(root);
            tree.setRoot(root);
            cout << "Root -> " << root << " is Either already set or changed Successfully!\n";
        }
        else if (choice == 2)
        {
            cout << "Enter value to insert: ";
            int value;
            cin >> value;
            validate(value);
            tree.insert(value);
            
            cout << "Value -> " << value << " is Either already present or inserted successfully!\n";
        }
        else if (choice == 3)
        {
            cout << "Enter value to remove: ";
            int value;
            cin >> value;
            validate(value);
            if (tree.deleteNode(value))
                cout << "Value removed successfully!\n";
            else
                cout << "value not found!\n";
        }
        else if (choice == 4)
        {
            cout << "Enter value to search for: ";
            int value;
            cin >> value;
            validate(value);
            BSTNode<int> *node = tree.search(value);
            if (node)
                node->printNode();
            else
                cout << "value not found!\n";
        }
        else if (choice == 5)
        {
            tree.printTree();
        }
        else if (choice == 6)
        {
            cout << "Height (Number of Level): " << tree.getHeight();
        }
        else if (choice == 7)
        {
            tree.printTree();
            cout << "\nThe tree is BST Now to test for invalid value Please enter a value for root to change and then test it is BST OR NOT: ";
            int root;
            cin >> root;
            validate(root);
            tree.test(root);
        }
        else if (choice == 8)
        {
            cout << "1st you have to make a tree to test with the one below\n";
            tree.printTree();
            cout << "Please make a tree: ";
            while (true)
            {
                cout << "Enter value to insert: ";
                int value;
                cin >> value;
                validate(value);
                tree1.insert(value);
                cout << "Value -> " << value << "is inserted successfully!\n";
                cout << "1 -> to insert another value\n2 -> to test the equality\n";
                cin >> value;
                while (value < 1 || value > 2)
                {
                    cout << "choice -> " << value << " is not valid\nRe-enter 1 OR 2: ";
                    cin >> value;
                }
                if (value == 2)
                {
                    if (tree.testIsEqual(tree, tree1))
                        cout << "Both tree are equal\n";
                    else
                        cout << "Tree are not equal\n";
                    break;
                }
            }
        }
        else if (choice == 9)
        {
            cout << "1 ->  to get Max Node\n 2 -> to get Min Node: ";
            int value;
            cin >> value;
            while (value < 0 || value > 1)
            {
                cout << "choice -> " << value << " is not valid\nRe-enter 0 OR 1: ";
                cin >> value;
            }
            if (value == 0)
                cout << "Min Node value is: " << tree.getMinMax(value) << endl;
            else
                cout << "Max Node value is: " << tree.getMinMax(value) << endl;
        }
        else if (choice == 10)
        {
            tree1 = tree;
            cout << " Here is the Copy\n";
            tree1.printTree();
        }
        else if (choice == 11)
        {
            cout << "No of Nodes: " << tree.getNodeCount(&tree) << endl;
        }
        else
            tree.print();
        cout << "\n________________________________________________________________";
        cout << "\nPress any key to continue..." << endl;
        system("pause>0");
    }
    return 0;
}
void validate(int &value)
{
    while (value < INT16_MIN || value > INT16_MAX)
    {
        cout << "Value must be between " << INT16_MIN << " and " << INT16_MAX << endl;
        cout << "Re-enter the value: ";
        cin >> value;
    }
}