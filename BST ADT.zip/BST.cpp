//  Abdul Aziz
//  BCSF19A026
//  CS Afternoon Add/Drop
#include "BST.h"
#include <iomanip>

template <typename T>
void BST<T>::makeBST(BSTNode<T> *cur, BSTNode<T> *orgRoot)
{
    if (cur)
    {
        if (cur->data > orgRoot->data)
            orgRoot = orgRoot->right = new BSTNode<T>(cur->data);
        if (cur->data < orgRoot->data)
            orgRoot = orgRoot->left = new BSTNode<T>(cur->data);
        makeBST(cur->left, orgRoot);
        makeBST(cur->right, orgRoot);
    }
}
template <typename T>
void BST<T>::deleteBST(BSTNode<T> *cur)
{

    if (cur)
    {
        deleteBST(cur->right);
        deleteBST(cur->left);
        delete cur;
        cur = NULL;
    }
}
template <typename T>
void BST<T>::LVR(BSTNode<T> *cur) const
{

    if (cur)
    {
        LVR(cur->left);
        cout << cur->data << "  ";
        LVR(cur->right);
    }
}
template <typename T>
int BST<T>::getNoOfNodes(BSTNode<T> *node)
{
    if (node)
    {
        int left = 0, right = 0;
        if (node->left)
            left = 1 + getNoOfNodes(node->left);
        if (node->right)
            right = 1 + getNoOfNodes(node->right);
        return left + right;
    }
    return 0;
}
template <typename T>
int BST<T>::getHeight(BSTNode<T> *node)
{
    if (node)
    {
        int l = getHeight(node->left);
        int r = getHeight(node->right);
        cout << l + 1 << " " << r + 1 << "\n";
        if (l > r)
            return l + 1;
        return r + 1;
    }
    return 0;
}
template <typename T>
void BST<T>::VLR(BSTNode<T> *cur) const
{
    if (cur)
    {
        cout << cur->data << "  ";
        VLR(cur->left);
        VLR(cur->right);
    }
}
template <typename T>
void BST<T>::LRV(BSTNode<T> *cur) const
{
    if (cur)
    {
        LRV(cur->left);
        LRV(cur->right);
        cout << cur->data << "  ";
    }
}

template <typename T>
BST<T>::BST(const BST<T> &obj)
{
    BSTNode<T> *cur = obj.root;
    if (!cur)
        root = NULL;
    else
    {
        root = new BSTNode<T>(obj.root->data);
        makeBST(obj.root, root);
    }
}
template <typename T>
const BST<T> &BST<T>::operator=(const BST<T> &obj)
{
    if (this == &obj)
        return *this;
    if (root)
        this->~BST();
    if (!obj.root)
        root = NULL;
    else
    {
        root = new BSTNode<T>(obj.root->data);
        makeBST(obj.root, root);
    }
    return *this;
}
template <typename T>
BST<T>::~BST()
{
    deleteBST(root);
    cout << endl;
}
// function
template <typename T>
BSTNode<T> *BST<T>::search(T key)
{
    BSTNode<T> *cur = root;
    while (cur)
    {
        if (cur->data == key)
            return cur;
        if (cur->data > key)
            cur = cur->left;
        else
            cur = cur->right;
    }
    return cur;
}
template <typename T>
void BST<T>::insert(T key)
{
    BSTNode<T> *cur = root, *pre = NULL;
    while (cur)
    {
        pre = cur;
        if (cur->data == key)
            return;
        if (cur->data > key)
            cur = cur->left;
        else
            cur = cur->right;
    }
    if (!pre)
        root = new BSTNode<T>(key);
    else
    {
        if (pre->data < key)
            pre->right = new BSTNode<T>(key);
        else
            pre->left = new BSTNode<T>(key);
    }
}
template <typename T>
bool BST<T>::deleteNode(T key)
{
    BSTNode<T> *cur = root, *pre = NULL;
    while (cur && cur->data != key)
    {
        pre = cur;
        if (cur->data > key)
            cur = cur->left;
        else
            cur = cur->right;
    }
    if (!cur)
        return false;
    // case degree 2
    if (cur->left && cur->right)
    {
        BSTNode<T> *r = cur->right, *pr = cur;
        while (r->left)
        {
            pr = r;
            r = r->left;
        }
        cur->data = r->data;
        cur = r;
        pre = pr;
    }
    // case degree 1
    // case degree 0
    BSTNode<T> *temp = NULL;
    if (cur->right)
        temp = cur->right;
    else
        temp = cur->left;
    if (!pre)
        root = temp;
    else
    {
        if (cur == pre->right)
            pre->right = temp;
        else
            pre->left = temp;
    }
    delete cur;
    cur = NULL;
    return true;
}
template <typename T>
void BST<T>::print() const
{
    cout << "LVR: ";
    LVR(root);
    cout << endl;
    cout << "VLR: ";
    VLR(root);
    cout << endl;
    cout << "LRV: ";
    LRV(root);
    cout << endl
         << endl;
}
template <typename T>
void BST<T>::setRoot(T value)
{
    if (!root)
        root = new BSTNode<T>(value);
    else
    {
        if (root->left && root->right && (value > root->left->data) && (value < root->right->data))
            root->data = value;
        else if (root->left && !root->right && (value > root->left->data))
            root->data = value;
        else if (!root->left && root->right && (value < root->right->data))
            root->data = value;
        else if (!root->right && !root->left)
            root->data = value;
    }
}
template <typename T>
BSTNode<T> *BST<T>::getLeftChild(BSTNode<T> *node)
{
    if (node->left)
        return node->left;
    else
        return NULL;
}
template <typename T>
BSTNode<T> *BST<T>::getRightChild(BSTNode<T> *node)
{
    if (node->right)
        return node->right;
    else
        return NULL;
}
template <typename T>
void BST<T>::printTree()
{
    if (root)
    {
        if (isBST(root))
            cout << "Tree is A valid BST Tree" << endl;
        else
            cout << "Tree is not A valid BST Tree" << endl;
        int hight = getHeight();
        queue<BSTNode<T> *> treeQueue;
        treeQueue.push(root);
        BSTNode<T> *node = NULL;
        int level = 1;
        for (int i = 0; i < hight; i++)
        {
            int j = 0;
            while (j < hight - i)
            {
                cout << setw(6) << "";
                j++;
            }
            j = 0;
            while (j < level)
            {
                if (!treeQueue.empty())
                {
                    node = treeQueue.front();
                    treeQueue.pop();
                }
                if (node)
                {
                    if (node->left)
                        treeQueue.push(node->left);
                    else
                        treeQueue.push(NULL);
                    if (node->right)
                        treeQueue.push(node->right);
                    else
                        treeQueue.push(NULL);
                    cout << setw(6) << node->data;
                }
                else
                    cout << setw(6) << "";
                j++;
                if (j * 2 == level)
                    cout << setw(3 * (hight - i)) << "";
            }
            cout << endl
                 << endl;
            level = level * 2;
        }
        cout << "--------------------------------";
    }
}
template <typename T>
bool BST<T>::isBST(BSTNode<T> *node)
{
    if (node)
    {
        if ((node->left && node->data < node->left->data) || (node->right && node->data > node->right->data))
            return false;
        bool flag1 = false;
        bool flag2 = false;
        flag1 = isBST(node->right);
        if (!flag1) return false;
        flag2 = isBST(node->left);
        if (flag1 && flag2)
            return true;
        else
            return false;
    }
    else
        return true;
}
template <typename T>
bool BST<T>::isEqual(BSTNode<T> *r1, BSTNode<T> *r2)
{
    if (!r1 && r2)
        return false;
    if (r1 && !r2)
        return false;
    if (r1 && r2)
    {
        if (r1->data != r2->data)
            return false;
        bool flag = isEqual(r1->left, r2->left);
        if (!flag)
            return false;
        bool flag1 = isEqual(r1->right, r2->right);
        if (flag1 == flag)
            return true;
        return false;
    }
    return true;
}
template <typename T>
int BST<T>::getHeight()
{
    return getHeight(root);
}
template <typename T>
int BST<T>::getNodeCount(BST<T> *bst)
{
    return 1 + getNoOfNode(bst->root);
}

template <typename T>
T BST<T>::getMinMax(int flag)
{
    if (!root)
    {
        cout << "Tree is empty" << endl;
        return -999;
    }
    if (flag)
    {
        BSTNode<T> *max = root;
        while (max->right)
            max = max->right;
        return max->data;
    }
    BSTNode<T> *min = root;
    while (min->left)
        min = min->left;
    return min->data;
}