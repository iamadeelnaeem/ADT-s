#define _CRT_SECURE_NO_WARNINGS
#include <cctype>
#include <cstring>
#include <string>
#include "MyList.h"
#include "Student.h"
//template <class T>
int main()
{
	MyList <int> a1(5, 4);
	cout << a1;
	cout << a1[1];
	Student std("Maya", 5);
	cout << std;
	MyList <Student> a2(5, std);
	cout << a2;
	cout << endl;
	cout << "-----------------\n";
	cout << a2[2];
	cout << "-----------------\n";


	MyList <MyList<Student>> matrix(5);


	/*for (int i = 0; i < 5; i++)
		matrix[i] = a2;*/


	for (int i = 0; i < 5; i++)
		matrix[i] = { i + 1,"Maya" };
	for (int i = 0; i < 5; i++)
		for (int j = 0; j <= i; j++)
			matrix[i][j] = { "Maya" ,i * 5 + j };
	cout << matrix;


	/*for (int i = 0; i < 6; i++)
		for (int j = 0; j < 6; j++)
			matrix[i][j] = std;*/



	int num = 6;
	MyList <MyList<int>> table(5, num);
	for (int i = 0; i < 5; i++)
		table[i] = { i + 1, i + 1 };
	cout << table;



	char arr[15] = "Hello World!";
	MyList <MyList <char*>> charArr(5);
	for (int i = 0; i < 5; i++)
		charArr[i] = (5);
	for (int i = 0; i < 5; i++)
	{
		for (int j = 0; j < 5; j++)
		{
			charArr[i][j] = arr;
			cout << charArr[i][j] << " ";
		}
		cout << endl;
	}
	//cout << charArr;
	return 0;
}