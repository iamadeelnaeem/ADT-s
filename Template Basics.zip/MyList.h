#pragma once
#include <iostream>
#include <iomanip>
using namespace std;
template <class T>
class MyList
{

private:
	T* list;
	int size;
public:
	//friend ostream& operator<<(ostream&, const MyList<T>&);
	MyList(int = 0, T = 0);
	MyList(const MyList&);
	const MyList& operator =(const MyList&);
	T& operator [] (int);
	~MyList();
	friend ostream& operator <<(ostream& out, const MyList <T>& rhs)
	{
		if (rhs.list)
		{
			cout << fixed << left;
			for (int i = 0; i < rhs.size; i++)
			{
				out <<setw(20) << rhs.list[i];
			}
			out << endl;
		}
		return out;
	}
};
template <class T>
MyList<T>::MyList(int s, T val)
{
	cout << "MyList Constructor Call\n";
	if (s)
	{
		list = new T[s];
		for (int i = 0; i < s; i++)
			list[i] = val;
		size = s;
	}
	else
	{
		list = NULL;
		size = 0;
	}
}
template <class T>
const MyList <T>& MyList<T> :: operator =(const MyList& rhs)
{
	if (this == &rhs)
		return *this;
	else
	{
		if (rhs.list)
		{
			list = new T[rhs.size];
			size = rhs.size;
			for (int i = 0; i < size; i++)
				list[i] = rhs.list[i];
		}
	}
	return *this;
}

template <class T>
MyList<T>::MyList(const MyList& rhs)
{
	if (rhs.list)
	{
		size = rhs.size;
		list = new T[size];
		for (int i = 0; i < size; i++)
			list[i] = rhs.list[i];
	}
	else
	{
		size = 0;
		list = NULL;
	}
}
template <class T>
T& MyList<T>:: operator [] (int a)
{
	return list[a];
}
template <class T>
MyList<T> :: ~MyList()
{
	cout << "MyList Destructor Call\n";
	if (list)
	{
		delete[]list;
		list = NULL;
	}
}

