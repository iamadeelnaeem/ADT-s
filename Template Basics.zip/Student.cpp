#include "Student.h"
Student::Student(const char* a, int b)
{
	cout << "Student Constructor\n";
	if (a)
	{
		name = new char[strlen(a)+1];
		strcpy(name, a);
	}
	else
		name = NULL;
	if (b > 0)
		id = b;
	else
		id = 0;
}
Student::Student(const Student& rhs)
{
	cout << "Copy Constructor Call\n";
	if (rhs.name)
	{
		name = new char[strlen(rhs.name)+1];
		strcpy(name, rhs.name);
	}
	else
		name = NULL;
	id = rhs.id;

}
const Student& Student::  operator = (const Student& rhs)
{
	cout << "operator= Call\n";
	if (this == &rhs)
		return *this;
	else
	{
		if (name)
		{
			delete[]name;
			name = NULL;
		}
		if (rhs.name)
		{
			name = new char[strlen(rhs.name)+1];
			strcpy(name, rhs.name);
			id = rhs.id;
		}
		return *this;
	}
}

Student :: ~Student()
{
	cout << "Student Destructor Call\n";
	if (name)
	{
		delete[]name;
		name = NULL;
	}
}
ostream& operator << (ostream& out, const Student& rhs)
{
	if (rhs.name)
		out << "Name: " << rhs.name <<"\tID: "<<rhs.id;
	return out;
}