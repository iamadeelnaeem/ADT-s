#pragma once
#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
using namespace std;
class Student
{
	char* name;
	int id;

public:
	Student(const char* = NULL, int = 0);
	Student(const Student&);
	const Student& operator = (const Student&);
	friend ostream& operator << (ostream&, const Student&);
	~Student();
};



